package edu.bsu.cs222;
import java.util.Random;
import java.util.LinkedList;

class Bot extends Player {
    private LinkedList<CardData> botHand;
    private String botDifficulty;
    private CardData chosenCard;
    private Random rand = new Random();

    Bot(String name, LinkedList<CardData> hand, LinkedList<ItemData> items, String difficulty) {
        super(name, hand, items);
        this.botHand = hand;
        this.botDifficulty = difficulty;
    }

    void cardChoice(CardData card)
    {
        chosenCard = card;
    }

    CardData getChosenCard()
    {
        return chosenCard;
    }

    CardData pickCard(String roundColor, int score) {
        CardData highestCard = this.getCardFromHand(0);
        if (botDifficulty.toLowerCase().equals("easy")) {//easy difficulty the bot chooses random card
            highestCard = selectRandomCard();
        }
        if (botDifficulty.toLowerCase().equals("medium")) {
            highestCard = selectBestCard(roundColor);//medium difficulty bot chooses best card
        }
        if (botDifficulty.toLowerCase().equals("hard"))//hard difficulty bot chooses weakest cards for 3 rounds then chooses highest card
        {
            if(score<3) {
                highestCard = selectWeakestCard();
            }
            else
            {
                highestCard = selectBestCard(roundColor);
            }
        }
        if (botDifficulty.toLowerCase().equals("impossible"))
        {
            highestCard = selectRandomCard();
        }
        removeCardFromHand(getCardIndex(highestCard));
        return highestCard;
    }

    private CardData selectRandomCard() {
        CardData highestCard;
        int i = rand.nextInt(this.botHand.size());
        highestCard = this.botHand.get(i);
        return highestCard;
    }
    private CardData selectBestCard(String roundColor)
    {
        CardData highestCard = getCardFromHand(0);
        LinkedList<CardData> hand = this.getHand();
        for (CardData card:hand) {
            if (roundColor.equals("red")) {
                if (card.getRed() > highestCard.getRed()) {
                    highestCard = card;
                }
            }
            if (roundColor.equals("green")) {
                if (card.getGreen() > highestCard.getGreen()) {
                    highestCard = card;
                }
            }
            if (roundColor.equals("blue")) {
                if (card.getBlue() > highestCard.getBlue()) {
                    highestCard = card;
                }
            }
        }
        return highestCard;
    }

    private CardData selectWeakestCard()
    {
        CardData weakestCard = getCardFromHand(0);
        int lowestCard = 3000;
        for (CardData card: botHand)
        {
            if(lowestCard > card.getHighestColorValue())
            {
                weakestCard = card;
                lowestCard = card.getHighestColorValue();
            }
        }
        return weakestCard;
    }

    @Override
    void printPlayedCards()
    {
        System.out.println(super.getPlayerName()+":");
        chosenCard.printCard();
        System.out.println("No Item");
        System.out.println("\n");
    }
}
