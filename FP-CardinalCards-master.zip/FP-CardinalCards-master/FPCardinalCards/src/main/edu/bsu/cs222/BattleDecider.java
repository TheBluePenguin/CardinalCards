package edu.bsu.cs222;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;

class BattleDecider {
    private String P1RPS;
    private int p1Red;
    private int p1Green;
    private int p1Blue;
    private String P2RPS;
    private int p2Red;
    private int p2Green;
    private int p2Blue;
    private String turnColor;
    private LinkedList<CardData> discardPile;
    private Player battlePlayer1;
    private Player battlePlayer2;
    Player clash(ArrayList<Player> playerList, String inGameTurnColor, LinkedList<CardData> currentDiscardPile)//Determines which card wins between all players.
    {
        Player victor = null;
        for(Player player : playerList) {
            for (Player otherPlayer : playerList) {
                if (player != otherPlayer) {
                if (player.getChosenItem() == null) {
                        ItemData itemEffect = new ItemData("No Item", null, 0);
                        player.itemChoice(itemEffect);
                    }
                    if (otherPlayer.getChosenItem() == null) {
                        ItemData itemEffect = new ItemData("No Item", null, 0);
                        otherPlayer.itemChoice(itemEffect);
                    }
                    //get number from corresponding color of player cards

                    battlePlayer1 = player;
                    battlePlayer2 = otherPlayer;

                    P1RPS = player.getChosenCard().getRPS();
                    P2RPS = otherPlayer.getChosenCard().getRPS();

                    p1Red = player.getChosenCard().getRed();
                    p1Green = player.getChosenCard().getGreen();
                    p1Blue = player.getChosenCard().getBlue();

                    p2Red = otherPlayer.getChosenCard().getRed();
                    p2Green = otherPlayer.getChosenCard().getGreen();
                    p2Blue = otherPlayer.getChosenCard().getBlue();

                    discardPile = currentDiscardPile;
                    turnColor = inGameTurnColor;

                    itemEffects(player, otherPlayer, player.getChosenItem(), otherPlayer.getChosenItem());
                    Player miniRoundVictor = colorWinner(player, otherPlayer, turnColor);
                    miniRoundVictor.playerWins();
                }
            }
        }
        int victoryCounter = 0;
        for(Player player : playerList) {
            if(player.getBattleScore() > victoryCounter)
            {
                victor = player;
                victoryCounter = player.getBattleScore();
            }
        }
        for(Player player : playerList)
        {
            player.resetBattleScore();
        }
        return victor;
    }

    private Player colorWinner(Player player1, Player player2, String turnColor) {
        Player winner = player1;
        if (turnColor.equals("red"))//Determines which turn color it is.
        {
            if (p1Red > p2Red)//checks player ones red to player two's red value
            {
                winner = player1;//winner gets announced
            } else {
                if (p2Red > p1Red) {
                    winner = player2;
                } else {
                    winner = RPSWinner(player1, player2);
                }
            }
        }
        if (turnColor.equals("green")) {
            if (p1Green > p2Green) {
                winner = player1;
            }
            else {
                if (p2Green > p1Green) {
                    winner = player2;
                } else {
                    winner = RPSWinner(player1, player2);
                }
            }
        }
        if (turnColor.equals("blue")) {
            if (p1Blue > p2Blue) {
                winner = player1;
            }
            else {
                if (p2Blue > p1Blue) {
                    winner = player2;
                } else {
                    winner = RPSWinner(player1, player2);
                }
            }
        }
        return winner;
    }

    private Player RPSWinner(Player player1, Player player2) {//compares rock paper scissors values and determines winner
        Player winner = player1;
        if (P1RPS.equals("Rock") && P2RPS.equals("Paper")) {
            winner = player2;
        }
        if (P1RPS.equals("Paper") && P2RPS.equals("Scissors")) {
            winner = player2;
        }
        if (P1RPS.equals("Scissors") && P2RPS.equals("Rock")) {
            winner = player2;
        }
        if (P2RPS.equals("Rock") && P1RPS.equals("Paper")) {
            winner = player1;
        }
        if (P2RPS.equals("Paper") && P1RPS.equals("Scissors")) {
            winner = player1;
        }
        if (P2RPS.equals("Scissors") && P1RPS.equals("Rock")) {
            winner = player1;
        }
        return winner;
    }

    private void ClippedWing(Player player){//lowest value of card chosen regardless of round color for the opponents

        if(player == battlePlayer2) {
            if (p1Red <= p1Green && p1Red <= p1Blue) {
                p1Green = p1Red;
                p1Blue = p1Red;
            }
            else {
                if (p1Green <= p1Red && p1Green <= p1Blue) {
                    p1Red = p1Green;
                    p1Blue = p1Green;
                } else {
                    p1Red = p1Blue;
                    p1Green = p1Blue;
                }
            }
        }
        if(player == battlePlayer1) {
            if (p2Red <= p2Green && p2Red <= p2Blue) {
                p2Green = p2Red;
                p2Blue = p2Red;
            }
            else {
                if (p2Green <= p2Red && p2Green <= p2Blue) {
                    p2Red = p2Green;
                    p2Blue = p2Green;
                } else {
                    p2Red = p2Blue;
                    p2Green = p2Blue;
                }
            }
        }
    }


    private void Updraft(Player player){//highest value chosen regardless of round color for item owner

        if(player == battlePlayer1) {
            if (p1Red >= p1Green && p1Red >= p1Blue) {
                p1Green = p1Red;
                p1Blue = p1Red;
            }
            if (p1Green >= p1Red && p1Green >= p1Blue) {
                p1Red = p1Green;
                p1Blue = p1Green;
            } else {
                p1Red = p1Blue;
                p1Green = p1Blue;
            }
        }
        if(player == battlePlayer2) {
            if (p2Red >= p2Green && p2Red >= p2Blue) {
                p2Green = p2Red;
                p2Blue = p2Red;
            }
            if (p2Green >= p2Red && p2Green >= p2Blue) {
                p2Red = p2Green;
                p2Blue = p2Green;
            } else {
                p2Red = p2Blue;
                p2Green = p2Blue;
            }
        }
    }


    private void Scavenger(Player player, LinkedList<CardData> discardPile) {
        Random rand = new Random();//gets 3 cards, adds them to player hand
        Scanner console = new Scanner(System.in);
        CardData card1 = discardPile.get(rand.nextInt(discardPile.size()));//removes same 3 cards from discard pile.
        discardPile.remove(card1);
        CardData card2 = discardPile.get(rand.nextInt(discardPile.size()));
        discardPile.remove(card2);
        CardData card3 = discardPile.get(rand.nextInt(discardPile.size()));
        discardPile.remove(card3);
        player.addCardToHand(card1);
        player.addCardToHand(card2);
        player.addCardToHand(card3);
        player.printCards();
        System.out.println("Select 2 cards you want to remove: ");//asks player which 2 cards two remove, discards them
        String removeCard1 = console.nextLine();
        String removeCard2 = console.nextLine();
        player.getCardByName(removeCard1);
        player.getCardByName(removeCard2);
    }

    private void HuntingSeason(String newColor)
    {
        turnColor = newColor;
    }

    private void itemEffects(Player player1, Player player2, ItemData P1effects, ItemData P2effects)
    {
        if (P2effects.getEffect()!=4) {
            switch (P1effects.getEffect()) {
                case 1://Bird Nest item card adds 5 points to all colors
                    if(p1Red+5<=55) {
                        p1Red = 55;
                    }
                    else
                    {
                        p1Red+=5;
                    }
                    if(p1Green+5<=55) {
                        p1Green = 55;
                    }
                    else
                    {
                        p1Green+=5;
                    }
                    if(p1Blue+5<=55) {
                        p1Blue = 55;
                    }
                    else
                    {
                        p1Blue+=5;
                    }
                    break;
                case 2://Clear Sky reveals other player's hand
                    System.out.println(player2.getPlayerName() + "'s hand:");
                    player2.printCards();
                    break;
                case 3://checks to see if discard pile has 3 or more cards
                    if (discardPile.size() >= 3) {
                        Scavenger(player1, discardPile);
                    } else {
                        System.out.println("Not enough cards in discard pile.");
                    }
                    break;
                case 5://Famine removes 3 points from other players cards
                    p2Red = p2Red - 3;
                    p2Green = p2Green - 3;
                    p2Blue = p2Blue - 3;
                    break;

                case 6://changes round color for that round
                    Scanner console = new Scanner(System.in);//gets the round color player chooses to play
                    System.out.println("What color does " + player1.getPlayerName() + " want to change it to?:");
                    String newColor = console.nextLine();
                    HuntingSeason(newColor);
                    break;
                case 7://Updraft uses highest point on card regardless of color
                    Updraft(player1);
                    break;

                case 8://ClippedWing uses opponents lowest point on card regardless of color
                    ClippedWing(battlePlayer1);
                    break;
            }
        }
        if(P1effects.getEffect() != 4) {
            switch (P2effects.getEffect()) {
                case 1:
                    p2Red = p2Red + 5;
                    p2Green = p2Green + 5;
                    p2Blue = p2Blue + 5;
                    break;
                case 2:
                    System.out.println(player1.getPlayerName() + "'s hand:");
                    player1.printCards();
                    break;
                case 3:
                    if (discardPile.size() >= 3) {
                        Scavenger(player2, discardPile);
                    } else {
                        System.out.println("Not enough cards in discard pile.");
                    }
                    break;
                case 5:
                    p1Red = p1Red - 3;
                    p1Green = p1Green - 3;
                    p1Blue = p1Blue - 3;
                    break;
                case 6:
                    Scanner console = new Scanner(System.in);//gets the round color player chooses to play
                    System.out.println("What color does " + player2.getPlayerName() + " want to change it to?:");
                    String newColor = console.nextLine();
                    HuntingSeason(newColor);
                case 7:
                    Updraft(player2);
                    break;

                case 8:
                    ClippedWing(battlePlayer2);
                    break;
            }
        }
    }
}
