package edu.bsu.cs222;

import java.util.Scanner;


class TextInterface{
    private Scanner myScanner = new Scanner(System.in);

    String playerSetUp(int iteration) {
        System.out.println("Hello! Please insert your name: ");
        String playerName = myScanner.nextLine();
        if (iteration > 0){
            playerName = myScanner.nextLine();
        }
        System.out.println("Is " + playerName + " correct?");

        System.out.println("1: Yes");
        System.out.println("2: No");

        int choice = myScanner.nextInt();

        if (choice == 1) {
            System.out.println("Great!");
        } else if (choice == 2) {
            System.out.println("Please re-enter your name.");

            playerName = myScanner.nextLine(); /* double is required to bypass faulty console skipping. */
            playerName = myScanner.nextLine();

            System.out.println("Ok, let's try this again. Is " + playerName + " correct?");

            System.out.println("1: Yes");
            System.out.println("2: No");

            choice = myScanner.nextInt();
            if (choice == 1) {
                System.out.println("You'd think knowing how to spell your own name would be second nature.");
            } else if (choice == 2) {
                System.out.println("Well that's too bad. " + playerName + " it is.");
            }

        }
        return playerName;
    }
}
