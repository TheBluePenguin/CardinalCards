package edu.bsu.cs222;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Objects;

class CardList {
    private LinkedList<CardData> cards = new LinkedList<>(); //Deck of cards

    CardList() throws IOException {
        String Name;
        String RPS;
        int val1;
        int val2;
        int val3;
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(Objects.requireNonNull(classLoader.getResource("CardValues.txt")).getFile()); //Read cards from text file.
        BufferedReader br = new BufferedReader(new FileReader(file));
        String delimiters = "[, .]";
        String[] tokens;
        String line;
        String text;
        while ((line = br.readLine()) != null) {//Separates file into individual items.
            text = line;
            tokens = text.split(delimiters);
            try {
                Name = tokens[0].replace("_", " ");//Changes underscores into spaces for viewing pleasure.
                RPS = tokens[1];
                val1 = Integer.parseInt(tokens[2]);
                val2 = Integer.parseInt(tokens[3]);
                val3 = Integer.parseInt(tokens[4]);

                CardData card = new CardData(Name, RPS, val1, val2, val3);
                cards.add(card);
            } catch (Exception ignored) {//There will never be an I/O Exception.
            }
        }
    }

    LinkedList<CardData> getCards() {//Returns deck for other methods.
        return cards;
    }
}