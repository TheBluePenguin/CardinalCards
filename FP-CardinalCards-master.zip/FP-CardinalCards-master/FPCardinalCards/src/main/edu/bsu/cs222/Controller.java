package edu.bsu.cs222;
import javafx.fxml.FXML;

import java.io.IOException;

public class Controller {

    @FXML
    public void startButton() {
        Main.closeScene();
    }
    @FXML
    public void tutorialButton() throws IOException { Main.tutorial(); }
    @FXML
    public void exitButton() { //Code stops functioning when actionEvent is deleted.
        System.exit(0);
    }

}