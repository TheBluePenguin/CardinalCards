package edu.bsu.cs222;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Objects;

public class Main extends Application {
    private static Stage primaryStage;
    private static javafx.scene.control.TextArea TutorialPrint;

    @Override
    public void start(Stage primaryStage) throws Exception{//loads the title screen
        Parent root = FXMLLoader.load(getClass().getResource("../../../resources/TitleScreen.fxml"));
        Main.TutorialPrint = new javafx.scene.control.TextArea();
        Main.primaryStage = primaryStage;
        Main.primaryStage.setTitle("Cardinal Cards");
        Main.primaryStage.setScene(new Scene(root, 1000,550));
        Main.primaryStage.show();
    }

    static void closeScene()
    {
        primaryStage.close();
    }

    static void tutorial() throws IOException {
        FXMLLoader loader = new FXMLLoader();//opens a new window for the manual, loading the tutorial screen
        loader.setLocation(Main.class.getResource("../../../resources/TutorialScreen.fxml"));
        TutorialPrint = loader.load();
        Stage tutorialStage = new Stage();
        tutorialStage.setTitle("Tutorial");
        tutorialStage.initModality(Modality.WINDOW_MODAL);
        tutorialStage.initOwner(primaryStage);
        Main.textAreaPrint();
        VBox container = new VBox(TutorialPrint);
        Scene scene = new Scene(container);
        tutorialStage.setScene(scene);
        tutorialStage.showAndWait();
    }

    private static void textAreaPrint() throws IOException{
        ClassLoader classLoader = Main.class.getClassLoader();
        File file = new File(Objects.requireNonNull(classLoader.getResource("manualStuff.txt")).getFile()); //Read cards from text file.
        BufferedReader br = new BufferedReader(new FileReader(file));
        String line;
        while ((line = br.readLine())!= null){
            TutorialPrint.appendText(line +"\n"); // display the found integer
        }
    }

    public static void main(String[] args) throws Exception {
        launch(args);
        //Stores names in from user input in the player set up to strings
        CardinalCards.cardinalCards();
    }
}