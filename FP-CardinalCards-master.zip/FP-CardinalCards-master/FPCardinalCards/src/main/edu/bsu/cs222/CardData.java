package edu.bsu.cs222;

class CardData {
    private String name;
    private String RPS;
    private int red;
    private int green;
    private int blue;


    CardData(String name, String RPS, int red, int green, int blue) {
        this.name = name;
        this.RPS = RPS;
        this.red = red;
        this.green = green;
        this.blue = blue;
    }

    void printCard()
    {
        System.out.println("Name: "+this.name+" RPS: "+this.RPS+" Red: "+this.red+" Green: "+this.green+" Blue: "+this.blue);
    }

    String getCardName()
    {
        return this.name;
    }

    String getRPS()
    {
        return this.RPS;
    }

    int getRed()
    {
        return this.red;
    }

    int getGreen()
    {
        return this.green;
    }

    int getBlue()
    {
        return this.blue;
    }

    int getHighestColorValue()
    {
        int highestValue = 0;
        if (this.red >= this.green && this.red >= this.blue)
        {
            highestValue=this.red;
        }
        if (this.green >= this.red && this.green >= this.blue)
        {
            highestValue=this.green;
        }
        if (this.blue >= this.green && this.blue >= this.red)
        {
            highestValue=this.blue;
        }
        return highestValue;
    }


}