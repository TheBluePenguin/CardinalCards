package edu.bsu.cs222;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;


class CardinalCards {
    static void cardinalCards() throws IOException, InterruptedException {
        BattleDecider arena = new BattleDecider();
        ArrayList<Player> playerList = new ArrayList<>();
        ArrayList<Bot> botList = new ArrayList<>();
        ArrayList<Player> gameList = new ArrayList<>();
        //creates new CardList object then gets the cards to list
        //creates CardList deck and discardPile
        gameStartup(playerList, botList, gameList);
        LinkedList<CardData> discardCardPile = new LinkedList<>();
        LinkedList<ItemData> discardItemPile = new LinkedList<>();

        String turnColor = "blue";
        boolean game = true;
        while (game) {//turnTimer determine the round color
            turnColor = turnCycle(turnColor);
            //Compares the cards chosen by the players
            playerMainPhase(playerList, turnColor, discardCardPile, discardItemPile);
            botMainPhase(botList, playerWithMostPoints(playerList), turnColor, discardCardPile);
            Player victor = arena.clash(gameList, turnColor, discardCardPile);
            System.out.println("\n \n \n \n \n \n \n \n" + victor.getPlayerName() + " wins the round! Cards played this round:");
            for (Player player : gameList) {
                player.printPlayedCards();
            }
            TimeUnit.SECONDS.sleep(4);//waits 4 seconds before initiating next round
            System.out.println("\n \n \n \n \n");
            for (Player player : gameList) {
                player.resetChosenItem();
                if (victor.equals(player)) {//adds one point to winner of round
                    player.playerAddPlayerScore();
                }
            }
            endPhase(discardCardPile, discardItemPile);
            for (Player player : gameList) {
                if (player.getPlayerScore() == 5) {//displays winner of game
                    System.out.println(player.getPlayerName() + " wins the game!");
                    game = false;
                }
            }
        }
    }

    private static String turnCycle(String currentTurn) {
        String turnColor = "red";
        if (currentTurn.equals("green")) {
            turnColor = "blue";
        }
        if (currentTurn.equals("red")) {
            turnColor = "green";
        }
        if (currentTurn.equals("blue")) {
            turnColor = "red";
        }
        return turnColor;
    }

    private static void gameStartup(ArrayList<Player> playerList, ArrayList<Bot> botList, ArrayList<Player> gameList) throws IOException {//sets up game, gets amount of players and bots
        CardList deck = new CardList();
        ItemList itemsList = new ItemList();
        DeckShuffler shuffler = new DeckShuffler();
        LinkedList<CardData> shuffledDeck = shuffler.shuffleDeck(deck);
        int playerTotal = playerNumber();
        int botTotal = botNumber();
        LinkedList<LinkedList<CardData>> hands = shuffler.cardDealer(shuffledDeck, playerTotal+botTotal);
        LinkedList<LinkedList<ItemData>> items = shuffler.shuffleItems(itemsList, playerTotal+botTotal);
        playerSetup(playerList, gameList, hands, items, playerTotal);
        botSetup(gameList, botList, hands, items, botTotal);
    }

    private static void playerMainPhase(ArrayList<Player> playerList, String turnColor, LinkedList<CardData> discardCardPile, LinkedList<ItemData> discardItemPile) {
        for (Player player : playerList) {
            System.out.println("The round color is " + turnColor + ". \n" + player.getPlayerName() + "'s Hand:");
            player.printCards();
            getCardChoice(player, discardCardPile);
            getItemChoice(player, discardItemPile);
        }
    }

    private static void getCardChoice(Player player, LinkedList<CardData> discardCardPile)
    {
        Scanner console = new Scanner(System.in);
        System.out.println(player.getPlayerName() + ", Choose your card: ");
        String playerCardName = console.nextLine();
        //Looks for card based on player1's input
        CardData playerCard = player.getCardByName(playerCardName);
        player.cardChoice(playerCard);
        discardCardPile.add(playerCard);
        player.removeCardFromHand(player.getCardIndex(playerCard));
    }

    private static void getItemChoice(Player player, LinkedList<ItemData> discardItemPile)
    {
        Scanner console = new Scanner(System.in);
        player.printItems();
        if (player.getItemsInHand() != null) {
            System.out.println(player.getPlayerName() + ", would you like to play an Item? (Y/N): ");
            String player1Item = console.nextLine();
            if (player1Item.toLowerCase().equals("y")) {
                System.out.println("Which item would you like to use?");
                String itemChoice = console.nextLine();
                player.itemChoice(player.getItemByName(itemChoice));
                player.removeItem();
                discardItemPile.add(player.getChosenItem());
            }
        }
    }

    private static void botMainPhase(ArrayList<Bot> botList, Player player,  String turnColor, LinkedList<CardData> discardCardPile) {
        for (Bot bot : botList) {
            CardData botCard = bot.pickCard(turnColor, player.getPlayerScore());
            bot.cardChoice(botCard);
            discardCardPile.add(botCard);
        }
    }

    private static void endPhase(LinkedList<CardData> discardCardPile, LinkedList<ItemData> discardItemPile) {
        System.out.println("Discard Pile:");
        System.out.println();
        for (CardData card : discardCardPile) {
            card.printCard();
        }
        System.out.println("Used Items Pile:");
        System.out.println();
        for (ItemData item : discardItemPile) {
            System.out.println(item.getItemName());
        }
    }

    private static void playerSetup(ArrayList<Player> playerList, ArrayList<Player> gameList, LinkedList<LinkedList<CardData>> hands, LinkedList<LinkedList<ItemData>> items, int playerTotal)
    {
        TextInterface setup = new TextInterface();
        for(int i=0; i<playerTotal; i++) {
            String playerName = setup.playerSetUp(i);
            Player player = new Player(playerName, hands.get(0), items.get(0));
            playerList.add(player);
            gameList.add(player);
        }
    }

    private static void botSetup(ArrayList<Player> gameList, ArrayList<Bot> botList, LinkedList<LinkedList<CardData>> hands, LinkedList<LinkedList<ItemData>> items, int botTotal) {
        String difficulty = setBotDifficulty();
        if (difficulty.toLowerCase().equals("impossible")) {
            LinkedList<CardData> kaibaHand = new LinkedList<>();
            for (int i = 0; i < 10; i++) {
                CardData blueEyes = new CardData("Blue-Eyes White Dragon", "Scissors", 2750, 2500, 3000);
                kaibaHand.add(blueEyes);
            }
            Bot setoKaiba = new Bot("Seto Kaiba", kaibaHand, items.get(1), difficulty);
            botList.add(setoKaiba);
            gameList.add(setoKaiba);
            if(hands.size()>2)
            {
                System.out.println("There can be only one Seto Kaiba!");
            }
        } else {
            for (int i = 0; i < botTotal; i++) {
                Bot bot = new Bot("Bot " + (i+1), hands.get(i + 1), items.get(i + 1), difficulty);
                botList.add(bot);
                gameList.add(bot);
            }
        }
    }

    private static String setBotDifficulty()
    {
        Scanner console = new Scanner(System.in);
        System.out.println("What difficulty would you like to play at (easy, medium, or hard)?");
        return console.nextLine();
    }

    private static int botNumber()
    {
        Scanner console = new Scanner(System.in);
        System.out.println("How many bots do you want to play against?");
        return console.nextInt();
    }

    private static int playerNumber()
    {
        Scanner console = new Scanner(System.in);
        System.out.println("How many players are there?");
        return console.nextInt();
    }

    private static Player playerWithMostPoints(ArrayList<Player> playerList)
    {
        Player topScorer = playerList.get(0);
        for (Player player : playerList)
        {
            if(topScorer.getPlayerScore()<player.getPlayerScore())
            {
                topScorer=player;
            }
        }
        return topScorer;
    }
}


