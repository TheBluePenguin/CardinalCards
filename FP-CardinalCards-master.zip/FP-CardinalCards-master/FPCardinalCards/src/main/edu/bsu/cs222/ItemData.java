package edu.bsu.cs222;

class ItemData {
    private String name;
    private String description;
    private int effectIndex;

    ItemData(String name, String effectDescription, int effectIndex)
    {
        this.name=name;
        this.description=effectDescription;
        this.effectIndex=effectIndex;
    }

    String getItemName()
    {
        return this.name;
    }

    String getItemDescription()
    {
        return this.description;
    }

    int getEffect()
    {
        return this.effectIndex;
    }

}