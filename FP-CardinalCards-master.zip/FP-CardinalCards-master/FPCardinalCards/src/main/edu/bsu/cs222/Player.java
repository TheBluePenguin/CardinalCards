package edu.bsu.cs222;

import java.util.LinkedList;

class Player {

    private LinkedList<CardData> cardsInHand;
    private LinkedList<ItemData> itemsInHand;
    private String playerName;
    private CardData chosenCard;
    private ItemData chosenItem;
    private int playerScore;
    private int battleScore;

    Player (String name, LinkedList<CardData> hand, LinkedList<ItemData> items)
    {

        this.playerName = name;
        this.cardsInHand = hand;
        this.itemsInHand = items;
    }

    void addCardToHand(CardData card) {
        cardsInHand.add(card);
    }

    void removeCardFromHand(int index)
    {
        cardsInHand.remove(index);
    }

    int getHandSize()
    {
        return cardsInHand.size();
    }

    CardData getCardFromHand(int index)
    {
        return cardsInHand.get(index);
    }

    LinkedList<CardData> getHand() {
        return this.cardsInHand;
    }

    String getPlayerName()
    {
        return this.playerName;
    }

    LinkedList<ItemData> getItemsInHand()
    {
        return this.itemsInHand;
    }

    void removeItem()
    {
        this.itemsInHand.remove(chosenItem);
    }

    void printCards()
    {
        for (CardData card : this.cardsInHand) {
            card.printCard();
        }
    }
    CardData getCardByName(String name)
    {
        int cardIndex = 0;
        for (int i = 0; i < this.getHandSize(); i++) {
            if (name.toLowerCase().equals(cardsInHand.get(i).getCardName().toLowerCase())) {
                cardIndex = i;
            }
        }
        return getCardFromHand(cardIndex);
    }

    int getCardIndex(CardData card)
    {
        return this.cardsInHand.indexOf(card);
    }

    void printItems() {
        for (ItemData item : this.getItemsInHand()) {
            System.out.println(item.getItemName());
            System.out.println(item.getItemDescription()+"\n");
        }
    }
    private ItemData getItem(int index)
    {
        return this.itemsInHand.get(index);
    }

    ItemData getItemByName(String name)
    {
        int itemIndex = 0;
        for (int i = 0; i < this.itemsInHand.size(); i++) {
            if (name.toLowerCase().equals(itemsInHand.get(i).getItemName().toLowerCase())) {
                itemIndex = i;
            }
        }
        return getItem(itemIndex);
    }

    void addItemToHand(ItemData item)
    {
        itemsInHand.add(item);
    }

    void cardChoice(CardData card)
    {
        chosenCard = card;
    }

    CardData getChosenCard()
    {
        return chosenCard;
    }

    void itemChoice(ItemData item)
    {
        chosenItem = item;
    }

    ItemData getChosenItem()
    {
        return chosenItem;
    }

    void resetChosenItem()
    {
        chosenItem = null;
    }

    int getPlayerScore()
    {
        return playerScore;
    }

    void playerAddPlayerScore()
    {
        playerScore+=1;
    }

    int getBattleScore()
    {
        return battleScore;
    }

    void playerWins()
    {
        battleScore+=1;
    }

    void resetBattleScore()
    {
        battleScore=0;
    }

    void printPlayedCards()
    {
        System.out.println(playerName+":");
        chosenCard.printCard();
        if(chosenItem != null) {
            System.out.println(chosenItem.getItemName());
            System.out.println(chosenItem.getItemDescription());
            System.out.println("\n");
        }
        else
        {
            System.out.println("No Item");
            System.out.println("\n");
        }
    }
}
