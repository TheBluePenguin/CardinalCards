package edu.bsu.cs222;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Objects;

class ItemList {
    private LinkedList<ItemData> items = new LinkedList<>();
    ItemList() throws IOException {
        String name;
        int index;
        String effectDescription;
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(Objects.requireNonNull(classLoader.getResource("ItemCards.txt")).getFile()); //Read cards from text file.
        BufferedReader br = new BufferedReader(new FileReader(file));
        String[] tokens;
        String line;
        String text;
        while ((line = br.readLine()) != null) {//Separates file into individual items.
            text = line;
            tokens = text.split(" ");
            try {
                name = tokens[0].replace("_", " ");//Changes underscores into spaces for viewing pleasure.
                effectDescription = tokens[1].replace("_", " ");
                index = Integer.parseInt(tokens[2]);
                ItemData item = new ItemData(name, effectDescription, index);
                items.add(item);
            } catch (Exception ignored) {//There will never be an I/O Exception.
            }
        }
    }

    LinkedList<ItemData> getItems()
    {
        return items;
    }
}
