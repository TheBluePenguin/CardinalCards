package edu.bsu.cs222;

import java.util.LinkedList;
import java.util.Random;

class DeckShuffler {
    LinkedList<CardData> shuffleDeck(CardList deck) {

        Random rand = new Random();
        LinkedList<CardData> shuffledDeck = new LinkedList<>();
        LinkedList<CardData> cardDeck = deck.getCards();
        while (cardDeck.size() != 0) {//Randomly shuffles deck into two hands.
            int i = rand.nextInt(cardDeck.size());
            CardData card = cardDeck.get(i);
            shuffledDeck.add(card);
            cardDeck.remove(card);
        }
        return shuffledDeck;
    }

    LinkedList<LinkedList<ItemData>> shuffleItems(ItemList items, int playerNumber) {

        Random rand = new Random();
        LinkedList<LinkedList<ItemData>> playerItems = new LinkedList<>();
        LinkedList<ItemData> itemList = items.getItems();
        for(int x=0; x<playerNumber; x++) {//Randomly shuffles deck into two hands.
            LinkedList<ItemData> itemsInHand = new LinkedList<>();
            for (int j = 0; j < 3; j++) {
                int i = rand.nextInt(itemList.size());
                ItemData item = itemList.get(i);
                itemsInHand.add(item);
            }
            playerItems.add(itemsInHand);
        }
        return playerItems;
    }

    LinkedList<LinkedList<CardData>> cardDealer(LinkedList<CardData> cardDeck, int players) {
        Random rand = new Random();
        LinkedList<CardData> dealingCardDeck = new LinkedList<>(cardDeck);

        LinkedList<LinkedList<CardData>> startingHands = new LinkedList<>();

        for(int i=0; i<players; i++) {
            LinkedList<CardData> playerCards = new LinkedList<>();
            for (int j = 0; j < 10; j++) {//Randomly shuffles deck into multiple hands.
                if(dealingCardDeck.size() == 0)
                {
                    dealingCardDeck = new LinkedList<>(cardDeck);
                }
                int x = rand.nextInt(dealingCardDeck.size());
                CardData card = dealingCardDeck.get(x);
                playerCards.add(card);
                dealingCardDeck.remove(card);
            }
            startingHands.add(playerCards);
        }
        return startingHands;
    }
}