package edu.bsu.cs222;

import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;

public class DeckShufflerTest {
    private CardList cards = new CardList();
    private DeckShuffler deck = new DeckShuffler();
    private ItemList items = new ItemList();

    public DeckShufflerTest() throws IOException {
    }

    @Test
    public void testShuffleDeck()
    {
        Assert.assertNotEquals(deck, deck.shuffleDeck(cards));
    }

    @Test
    public void testShuffleItems()
    {
        Assert.assertNotEquals(items, deck.shuffleItems(items, 1));
    }

    @Test
    public void testCardDealer()
    {
        Assert.assertEquals(5, deck.cardDealer(deck.shuffleDeck(cards), 5).size());
    }
}
