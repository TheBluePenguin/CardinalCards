package edu.bsu.cs222;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.LinkedList;

public class ItemTest {
    private BattleDecider arena = new BattleDecider();
    private CardData card1 = new CardData("Emu", "Rock", 33, 22, 44);
    private CardData card3 = new CardData("Seagull", "Scissors", 22, 44, 33);
    private LinkedList<CardData> p1Hand = new LinkedList<>();
    private LinkedList<CardData> discardPile = new LinkedList<>();

    private LinkedList<ItemData> p1Items = new LinkedList<>();
    private ItemData BirdNest = new ItemData("Bird Nest", null, 1);
    private ItemData CockBlock = new ItemData("Cock Block", null, 4);
    private ItemData Famine = new ItemData("Famine", null, 5);
    private ItemData Updraft = new ItemData("Updraft", null, 7);
    private ItemData Downburst = new ItemData("Downburst", null, 8);

    private LinkedList<CardData> bot2Hand = new LinkedList<>();

    @Test
    public void testBirdNest(){
        ArrayList<Player> playerList = new ArrayList<>();
        bot2Hand.add(card3);

        p1Hand.add(card3);
        p1Items.add(BirdNest);
        Player player = new Player("Steve", p1Hand, p1Items);
        player.cardChoice(card3);
        Bot mediumBot = new Bot("Dave", bot2Hand, null, "medium");
        mediumBot.cardChoice(mediumBot.pickCard("red", 0));
        playerList.add(player);
        playerList.add(mediumBot);
        Assert.assertEquals(player, arena.clash(playerList, "red", discardPile));

    }

    @Test
    public void testCockBlock(){
        ArrayList<Player> playerList = new ArrayList<>();
        bot2Hand.add(card3);
        p1Hand.add(card1);
        p1Items.add(CockBlock);
        Player player = new Player("Steve", p1Hand, p1Items);
        Bot mediumBot = new Bot("Dave", bot2Hand, null, "medium");
        player.cardChoice(card1);
        player.itemChoice(CockBlock);
        mediumBot.cardChoice(mediumBot.pickCard("red", 0));
        mediumBot.itemChoice(Updraft);
        playerList.add(player);
        playerList.add(mediumBot);
        Assert.assertEquals(player, arena.clash(playerList, "red", discardPile));
    }

    @Test
    public void testFamine(){
        ArrayList<Player> playerList = new ArrayList<>();
        bot2Hand.add(card3);
        p1Hand.add(card3);
        p1Items.add(Famine);
        Player player = new Player("Steve", p1Hand, p1Items);
        Bot mediumBot = new Bot("Dave", bot2Hand, null, "medium");
        player.cardChoice(card3);
        player.itemChoice(Famine);
        mediumBot.cardChoice(mediumBot.pickCard("red", 0));
        playerList.add(player);
        playerList.add(mediumBot);
        Assert.assertEquals(player, arena.clash(playerList, "red", discardPile));

    }

    /*@Test
    public void testHuntingSeason(){
        bot2Hand.add(card2);
        p1Hand.add(card3);
        Player player = new Player("\Steve", p1Hand, p1Items);
        arena.huntingSeason(player);
    }*/

    @Test
    public void testUpdraft(){
        ArrayList<Player> playerList = new ArrayList<>();
        bot2Hand.add(card1);
        p1Hand.add(card1);
        p1Items.add(Updraft);
        Player player = new Player("Steve", p1Hand, p1Items);
        Bot mediumBot = new Bot("Dave", bot2Hand, null, "medium");
        player.cardChoice(card1);
        player.itemChoice(Updraft);
        mediumBot.cardChoice(mediumBot.pickCard("red", 0));
        playerList.add(player);
        playerList.add(mediumBot);
        Assert.assertEquals(player, arena.clash(playerList, "red", discardPile));
    }

    @Test
    public void testClippedWing(){
        ArrayList<Player> playerList = new ArrayList<>();
        bot2Hand.add(card3);
        p1Hand.add(card1);
        p1Items.add(Downburst);
        Player player = new Player("Steve", p1Hand, p1Items);
        Bot mediumBot = new Bot("Dave", bot2Hand, null, "medium");
        player.cardChoice(card1);
        player.itemChoice(Updraft);
        mediumBot.cardChoice(mediumBot.pickCard("red", 0));
        playerList.add(player);
        playerList.add(mediumBot);
        Assert.assertEquals(player, arena.clash(playerList, "red", discardPile));
    }
}
