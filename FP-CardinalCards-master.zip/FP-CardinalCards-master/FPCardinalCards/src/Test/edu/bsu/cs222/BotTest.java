package edu.bsu.cs222;


import org.junit.Assert;
import org.junit.Test;

import java.util.LinkedList;

public class BotTest {
    private CardData card1 = new CardData("Emu", "Rock", 33, 22, 44);
    private CardData card2 = new CardData("Finch", "Paper", 44, 33, 22);
    private CardData card3 = new CardData("Seagull", "Scissors", 22, 44, 33);
    private CardData card4 = new CardData("Blue-eyes White Dragon", "Paper", 55,55,55);
    private CardData card5 = new CardData("Dodo Bird", "Rock", 1,1,1);
    private LinkedList<CardData> mediumBotHand = new LinkedList<>();
    private LinkedList<CardData> hardBotHand = new LinkedList<>();
    private Bot mediumBot = new Bot("Dave", mediumBotHand, null, "medium");
    private Bot hardBot = new Bot("Steve", hardBotHand, null, "hard");

    @Test
    public void mediumBotTestRed()
    {
        mediumBotHand.add(card1);
        mediumBotHand.add(card2);
        mediumBotHand.add(card3);
        mediumBot.cardChoice(mediumBot.pickCard("red", 4));
        Assert.assertEquals("Finch", mediumBot.getChosenCard().getCardName());
    }

    @Test
    public void mediumBotTestGreen()
    {
        mediumBotHand.add(card1);
        mediumBotHand.add(card2);
        mediumBotHand.add(card3);
        mediumBot.cardChoice(mediumBot.pickCard("green", 4));
        Assert.assertEquals("Seagull", mediumBot.getChosenCard().getCardName());
    }

    @Test
    public void mediumBotTestBlue()
    {
        mediumBotHand.add(card1);
        mediumBotHand.add(card2);
        mediumBotHand.add(card3);
        mediumBot.cardChoice(mediumBot.pickCard("blue", 4));
        Assert.assertEquals("Emu", mediumBot.getChosenCard().getCardName());
    }

    @Test
    public void hardBotTest()
    {
        hardBotHand.add(card4);
        hardBotHand.add(card5);
        hardBot.cardChoice(hardBot.pickCard("red", 0));
        Assert.assertEquals("Dodo Bird", hardBot.getChosenCard().getCardName());
    }
}