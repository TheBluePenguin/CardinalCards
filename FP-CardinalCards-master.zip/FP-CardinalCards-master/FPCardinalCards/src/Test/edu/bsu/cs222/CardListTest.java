package edu.bsu.cs222;

import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;

public class CardListTest {
@Test
//Test to see if get cardCard method apart of cardList returns the list pulled
    public void testGetCard() throws IOException {
        CardList test = new CardList();
        Assert.assertNotNull(test.getCards());
    }
}
