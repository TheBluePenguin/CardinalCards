package edu.bsu.cs222;

import org.junit.Assert;
import org.junit.Test;

import java.util.LinkedList;

public class PlayerTest {
    private LinkedList<CardData> playerHand = new LinkedList<>();
    private LinkedList<ItemData> playerItems = new LinkedList<>();
    private Player player = new Player("Steve", playerHand, playerItems);

    @Test
    public void testGetCardByName()
    {
        CardData testCard = new CardData("Success", "Rock", 33, 33, 33);
        player.addCardToHand(testCard);
        Assert.assertEquals(testCard, player.getCardByName("Success"));
    }

    @Test
    public void testGetItemByName()
    {
        ItemData testItem = new ItemData("Updraft", null, 7);
        player.addItemToHand(testItem);
        Assert.assertEquals(testItem, player.getItemByName("Updraft"));
    }

    @Test
    public void testGetHandSize()
    {
        CardData card1 = new CardData("Card1", "Rock", 33, 33, 33);
        playerHand.add(card1);
        playerHand.add(card1);
        playerHand.add(card1);
        Assert.assertEquals(3, player.getHandSize());
    }
}
