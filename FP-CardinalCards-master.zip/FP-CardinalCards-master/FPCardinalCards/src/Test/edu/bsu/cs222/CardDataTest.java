package edu.bsu.cs222;

import org.junit.Assert;
import org.junit.Test;

public class CardDataTest {
    private CardData card1 = new CardData("Snowflipper Penguin", "Rock", 22,33,44);

    @Test
    public void testGetName()
    {
        Assert.assertEquals("Snowflipper Penguin", card1.getCardName());
    }

    @Test
    public void testGetRPS()
    {
        Assert.assertEquals("Rock", card1.getRPS());
    }

    @Test
    public void testGetRed()
    {
        Assert.assertEquals(22, card1.getRed());
    }

    @Test
    public void testGetGreen()
    {
        Assert.assertEquals(33, card1.getGreen());
    }

    @Test
    public void testGetBlue()
    {
        Assert.assertEquals(44, card1.getBlue());
    }
}
