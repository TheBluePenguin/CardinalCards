package edu.bsu.cs222;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.LinkedList;

public class BattleDeciderTest {
    private BattleDecider arena = new BattleDecider();
    private CardData player1Card = new CardData("Even33", "Rock", 33, 33, 33);
    private CardData player2Card = new CardData("HighRedLowBlue", "Paper", 44, 33, 22);
    private CardData player3Card = new CardData("LowAll", "Rock", 22, 22, 22);
    private CardData player4Card = new CardData("HighBlueLowGreen", "Scissors", 33, 22, 44);
    private CardData player5Card = new CardData("HighGreenLowRed", "Rock", 22, 44, 33);
    private CardData player6Card = new CardData("ObjectivelyBad", "Paper", 1, 1, 1);
    private CardData player7Card = new CardData("ObjectivelyAlmostGood", "Scissors", 50, 50, 50);
    private CardData player8Card = new CardData("ObjectivelyGood", "Paper", 55, 55, 55);
    private LinkedList<CardData> playerHand = new LinkedList<>();
    private Player player1 = new Player("player1", playerHand, null);
    private Player player2 = new Player("player2", playerHand, null);
    private Player player3 = new Player("player3", playerHand, null);
    private Player player4 = new Player("player4", playerHand, null);
    private Player player5 = new Player("player5", playerHand, null);
    private Player player6 = new Player("player6", playerHand, null);
    private Player player7 = new Player("player7", playerHand, null);
    private Player player8 = new Player("player8", playerHand, null);
    private LinkedList<CardData> discardPile = new LinkedList<>();

    @Test
    public void BattleTestRed() {
        ArrayList<Player> playerList = new ArrayList<>();
        playerList.add(player1);
        playerList.add(player2);
        player1.cardChoice(player1Card);
        player2.cardChoice(player2Card);
        Assert.assertEquals(player2, arena.clash(playerList, "red", discardPile)); //Test Normal Victory for Player 2
    }

    @Test
    public void BattleTestGreen() {
        ArrayList<Player> playerList = new ArrayList<>();
        playerList.add(player1);
        playerList.add(player2);
        player1.cardChoice(player1Card);
        player2.cardChoice(player2Card);
        Assert.assertEquals(player2, arena.clash(playerList,"green", discardPile)); //Test Tiebreaker

    }

    @Test
    public void BattleTestBlue() {
        ArrayList<Player> playerList = new ArrayList<>();
        playerList.add(player1);
        playerList.add(player2);
        player1.cardChoice(player1Card);
        player2.cardChoice(player2Card);
        Assert.assertEquals(player1, arena.clash(playerList,"blue",discardPile)); // Test Normal Victory for Player 1
    }

    @Test
    public void BattleTestFourPlayers() {
        ArrayList<Player> playerList = new ArrayList<>();
        playerList.add(player1);
        playerList.add(player2);
        playerList.add(player3);
        playerList.add(player4);
        player1.cardChoice(player1Card);
        player2.cardChoice(player2Card);
        player3.cardChoice(player3Card);
        player4.cardChoice(player4Card);
        Assert.assertEquals(player4, arena.clash(playerList,"blue",discardPile));
    }

    @Test
    public void BattleTestEightPlayers() {
        ArrayList<Player> playerList = new ArrayList<>();
        playerList.add(player1);
        playerList.add(player2);
        playerList.add(player3);
        playerList.add(player4);
        playerList.add(player5);
        playerList.add(player6);
        playerList.add(player7);
        playerList.add(player8);
        player1.cardChoice(player1Card);
        player2.cardChoice(player2Card);
        player3.cardChoice(player3Card);
        player4.cardChoice(player4Card);
        player5.cardChoice(player5Card);
        player6.cardChoice(player6Card);
        player7.cardChoice(player7Card);
        player8.cardChoice(player8Card);
        Assert.assertEquals(player8, arena.clash(playerList,"red",discardPile));
    }
}
