# FP-CardinalCards
Made by: Zachary Criswell, Michael Domaracki, Noah Mcneal, Drew Ellery

# Important Build notices:
When cloning the project, a popup will appear in the bottom right corner.
"Maven projects needs to be imported" 
You must select enable Auto-Import.
Sometimes the main folder will not be marked as the Sources root.
If it is grey on cloning, you must select it as your Source Root directory

# Game deisgn
This is a card game designed for 2-4 players. (currently only works for 1 player and a bot, or 2 real players)
It can easily be played by anyone above the age of 9.

# Instructions
Each player will be given a deck of 10 unique cards.
Each card will contain 5 values, a name, a rock/paper/scissors element, a red number, green number, and blue number.
The game will be played in a sequence of rounds identified by their color. The order is as follows, Red, Green, and Blue. (on repeate)
The player will choose a card they belive will have a larger value than their oppoents 
(example, player1 plays a card with a red value of 30, and player2 plays a card with a red value of 35)
Player2 would win that round.
Player1, and player2 would both discard the cards just used, and now be limited to 9 cards in their hand.
For each round won, that players score will be increased by 1.
The game ends when one player reachers 5 win points.

Each player will also be given 3 unquie item cards. Item cards can be played in any given round along with your regular card.
But the item card will be discarded after its use. (even if its a draw). Item cards include a description on what it does. 
(Such as showing your oponents hand, or giving you a point buff).

If two cards of equal value are played, then the rock/paper/scissors element will take place to win the round
if two cards have both equal color value, and the same rock/paper/scissors, 
the round will be a draw, the cards will not be disposed, and the next round will begin.

If the no player reaches 5 points before running out of card, all players will recive 
5 more cards from the discard pile, and the game will continue as normal.

# Warnings
TextInterface has two myScanner.nextLine()'s to compensate for nextLine()'s habit of usinng previous enter-key strokes as inputs.
